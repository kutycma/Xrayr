---
name: "Phản hồi lỗi"
about: Tạo báo cáo để giúp chúng tôi sửa chữa và cải thiện XrayR
title: ''
labels: awaiting reply, bug
assignees: ''
---

**Mô tả lỗi**
Mô tả ngắn gọn lỗi là gì

**lặp lại**
Các bước tái tạo lỗi

**Môi trường và phiên bản**
 - hệ thống [Ví dụ：Debian 11]
 - Ngành kiến ​​​​trúc [Ví dụ：AMD64]
 - Bảng điều khiển [Ví dụ：V2board]
 - Giao thức [Ví dụ：vmess]
 - Phiên bản [Ví dụ：1.1.1]

**nhật ký và lỗi**
Vui lòng sử dụng `xrayr log` để xem và thêm nhật ký để giúp giải thích sự cố của bạn

**nội dung bổ sung**
Thêm bất cứ điều gì khác về câu hỏi ở đây