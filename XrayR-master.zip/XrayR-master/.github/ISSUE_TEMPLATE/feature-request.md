---
name: "Đề xuất tính năng"
about: Cung cấp cho XrayR một đề xuất để cải thiện chúng tôi
title: ''
labels: đang chờ trả lời, yêu cầu tính năng
assignees: ''
---

**Mô tả chức năng bạn muốn**

Mô tả chức năng rõ ràng và ngắn gọn。

**Mô tả các lựa chọn thay thế bạn đã xem xét** 

Có bất kỳ lựa chọn thay thế nào để giải quyết vấn đề này không? 

**Bối cảnh bổ sung** 

Thêm bất kỳ bối cảnh hoặc ảnh chụp màn hình bổ sung nào về yêu cầu tính năng tại đây.