// Package dispather implement the rate limiter and the onlie device counter
package mydispatcher

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen
